﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//-Jared Bumgardner
//-Trevor Paulding
//-Project 1
//-2/8/2017

namespace Project1
{
    class Program
    {
        static void Main(string[] args)
        {
            //create and display diamond
            Diamond mainDiamond = new Diamond();
            mainDiamond.setHeight(9);
            mainDiamond.printMe();

            //end program
            //Console.Write("\nPress enter to continue...");
            //Console.ReadLine();

            return;
        }   //end main

        public class Diamond
        {
            //constructors
            public Diamond()
            {
                diamondHeight = 9;
            }
            public Diamond(int height)
            {
                diamondHeight = height;
            }

            //properties
            int diamondHeight = 0;

            //functions
            public int getHeight()
            {
                return diamondHeight;
            }   //getter
            public void setHeight(int newHeight)
            {
                diamondHeight = newHeight;
            }   //setter
            public void printMe()
            {
                //declarations
                int diamondHeight = getHeight();
                int currAstrix = 1;
                int currWhiteSpace = (getHeight()) / 2;
                int j = 1, k = 1;

                //display up portion of diamond
                for (int i = 0; i <= diamondHeight / 2; i++) //Trevor - I edited int i to be value 0
                {
                    while (j <= currWhiteSpace)
                    {
                        Console.Write(" ");
                        j++;
                    }
                    while (k <= currAstrix)
                    {
                        Console.Write("*");
                        k++;
                    }

                    j = 1;
                    k = 1;
                    currAstrix += 2;
                    currWhiteSpace--;
                    Console.WriteLine(); //Trevor - I removed the "t" from this
                }
                //Trevor - I added an "inverse" of the loop above
                currAstrix -= 4;
                currWhiteSpace += 4;

                for (int i = 4; i > 0; i--)
                {
                    while (j <= currWhiteSpace / 2)
                    {
                        Console.Write(" ");
                        j++;
                    }
                    while (k <= currAstrix)
                    {
                        Console.Write("*");
                        k++;
                    }
                    j = 1;
                    while (j <= currWhiteSpace / 2)
                    {
                        Console.Write(" ");
                        j++;
                    }

                    j = 1;
                    k = 1;
                    currAstrix -= 2;
                    currWhiteSpace += 2;
                    Console.WriteLine();
                }
            }
        }   //end diamond
    } //end program
} //end project1