#!/usr/bin/python

from genericStack import Stack

s = Stack(5)
print(s.getCount())
s.push(5)
s.push(8)
s.push(123)
print(s.items)